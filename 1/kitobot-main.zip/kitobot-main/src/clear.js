const help = (prefix) => {
	return `
   𝑻𝑬𝑨𝑴 𝑀𝑂𝐷𝐷𝐸𝑅♞𝑹𝑨𝑵𝑲𝑰𝑵𝑮 𝐼𝑀𝑈𝑁𝐸
𝗽𝗮𝗿𝗮 𝘂𝘀𝗮𝗿 𝗼 𝗯𝗼𝘁, 𝗺𝗮𝗻𝗱𝗮 ${prefix}𝗿𝗴 (𝗻𝗶𝗰𝗸)

◪ 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗢𝗘𝗦
  ❏ Prefix: 「  ${prefix}  」
  ❏ Criador : 𝑲𝐈𝐓𝐎'𝐗𝐒
  ❏${prefix}criador
  ❏${prefix}criadorgrupo
  
◪𝗠𝗘𝗡𝗨𝗦
  ❏${prefix}apks (apks pra edita zap)
  ❏${prefix}basesam (bases pra zap)
  ❏${prefix}kitomenu
  ❏${prefix}menuadmin
  ❏${prefix}menulinks (agr ta com imunes novos)
  
◪ 𝗙𝗔𝗭𝗘𝗥
▻${prefix}pinterest 
▻${prefix}idiomas (idiomas do comando ${prefix}/tts)
▻${prefix}wiki (olha na wikipedia em indonesio)
▻${prefix}imagem (transforma fig em imagem)
▻${prefix}play (nome da musica q quer baixar)
▻${prefix}tts (pt) (texto q vc quer q fale)
▻${prefix}memeindo (meme em ingles)
▻${prefix}fig (imagem ou gif ate 6 seg)
▻${prefix}wame (link pro seu chat)
▻${prefix}wikien (tbm n sei oq faz)
▻${prefix}meme (a msm coisa)
▻${prefix}virtex (sla oq faz)
▻${prefix}simi (texto)
▻${prefix}linkgrup
▻${prefix}listadm
     `
}

exports.help = help
