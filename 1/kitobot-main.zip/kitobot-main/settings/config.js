const config = {
        botName: 'kitobot',
        ownerName: 'kito',
        ,
}
