const kitomenu = (prefix, pushname) => {
    return `
comandos do 𝑲𝐈𝐓𝐎

▻${prefix}prefixo
▻${prefix}block
▻${prefix}bc
▻${prefix}bcgc
▻${prefix}limpar
`

}

exports.kitomenu = kitomenu