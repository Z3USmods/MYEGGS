const menulinks = (prefix, pushname) => {
 return `
🜲𝐌𝐄𝐍𝐔 𝐃𝐄 𝐋𝐈𝐍𝐊𝐒🜲
  
               🜲𝗔𝗣𝗣𝗦🜲
 𒆕𝗧𝗘𝗫𝗧𝗡𝗢𝗪
 http://www.mediafire.com/file/86704f30fz4lm7n/%25F0%259F%2591%258D%25F0%259F%2598%258ETEXTNOW.apk/file
 
𒆕𝗠𝗜𝗡𝗘𝗖𝗥𝗔𝗙𝗧
https://www.mediafire.com/file/khqflpzr02u721m/minecraft-1-16-201-01-xbox-servers.apk/file

𒆕𝗦𝗣𝗢𝗧𝗙𝗬 𝗣𝗥𝗢
https://www.mediafire.com/file/1sthqzz9d99pc4o/SPOTFY+PREMIUM+ATUALIZADO+2021+%C2%A9007Apk's.apk/file

              🜲𝗜𝗠𝗨𝗡𝗘𝗦 𝗣𝗥𝗜𝗠𝗔𝗥𝗜𝗢𝗦🜲
              
              𝗜𝗠𝗨𝗡𝗘 𝗗𝗘 𝗨𝗠 𝗣𝗔𝗥𝗖𝗘𝗜𝗥𝗢
 https://enrt.eu/QlVzK 
 passa pelo encurta pra ta insentivando o trabalho dele
 imune mto bonito slc, tudo de bom
 
𒆕𝗕𝗔𝗦𝗘=ҒᎬ̂ΝᏆХ V10
https://www.mediafire.com/file/0tz5xqd5jilor0e/F%25C3%258ANIX_V10base.apk/file

𒆕BILLS_DBZ V9
https://www.mediafire.com/file/06ztdp21v4rewzr/BILLS_DBZ_V9.apk/file

𒆕⏤͟͟͞͞𝐈𝐌𝚯𝐑𝐓∆𝐋ϟ𝐕𝟚𝟟♞🔥
http://www.mediafire.com/file/dxurelghjmcwecx/%25E2%258F%25A4%25CD%259F%25CD%259E%25CD%259F%25CD%259E%25F0%259D%2590%2588%25F0%259D%2590%258C%25F0%259D%259A%25AF%25F0%259D%2590%2591%25F0%259D%2590%2593%25E2%2588%2586%25F0%259D%2590%258B%25CF%259F%25F0%259D%2590%2595%25F0%259D%259F%259A%25F0%259D%259F%259F%25E2%2599%259E%25F0%259F%2594%25A5.apk/file

𒆕ꪶ𝑻𝑰𝑶 𝑷𝑶𝒁𝑬 𝑽4ꫂ
http://www.mediafire.com/file/68isf6jukot1w27/%EA%AA%B6????????????+????????????????+????4%EA%AB%82.apk/file

              🜲𝗜𝗠𝗨𝗡𝗘𝗦 𝗦𝗘𝗖𝗨𝗡𝗗𝗔𝗥𝗜𝗢𝗦🜲
𒆕𓆲 𝜟͢𝐿𝐶𝐻͢𝜩𝑀𝛪𝑆𝛵 𖧓
http://www.mediafire.com/file/bv65vukgmg6a1kk/%25F0%2593%2586%25B2%25C2%25A0%25F0%259D%259C%259F%25CD%25A2%25F0%259D%2590%25BF%25F0%259D%2590%25B6%25F0%259D%2590%25BB%25CD%25A2%25F0%259D%259C%25A9%25F0%259D%2591%2580%25F0%259D%259B%25AA%25F0%259D%2591%2586%25F0%259D%259B%25B5%25C2%25A0%25F0%2596%25A7%2593_BY_%25F0%259D%2591%25AA%25F0%259D%2591%25B5%25F0%259D%2591%25B4%25F0%259D%2591%25B6%25F0%259D%2591%25AB%25F0%259D%2591%25BA.apk/file

𒆕꧁岌玄亇〄 V21꧂
https://www.mediafire.com/file/jfiarqmyc8gg54j/WA%25EA%25A7%2581%25E5%25B2%258C%25E7%258E%2584%25E4%25BA%2587%25E3%2580%2584_V21%25EA%25A7%2582SEC.apk/file

𒆕• 𝐃𝐄𝐀𝐓𝐇 𝐖𝐀 𝐕𝟓 𝐓𝐔𝐍𝐍𝐄𝐃 •
https://mega.nz/file/bs0DzQBI#JmUHB4SNmKgkzWZZHjN1Vm3YRTQ-qpLJjuxNaIV0MhQ

 `


}

exports.menulinks = menulinks