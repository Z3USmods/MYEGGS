const menuadmin = (prefix, pushname) => {
 return `    K҉ I҉T҉O҉B҉O҉T҉  D҉O҉M҉IN҉A҉
 da adm pro bot faz isso
 
 ◪ COMANDO DOS ADMINS
▻${prefix}bemvindo (da as boas vindas)
▻${prefix}marcar (marca todos)
▻${prefix}d (apaga msg do bot)
▻${prefix}leave (bot mete o pé)
▻${prefix}leveling (liga o level)
▻${prefix}add 5528999...
▻${prefix}promover @
▻${prefix}fechargrupo
▻${prefix}abrirgrupo
▻${prefix}demote @
▻${prefix}kick @
▻${prefix}ping
▻${prefix}level
 `


}

exports.menuadmin = menuadmin